LLM_MODEL = "llama3.1"            # any Ollama model that supports tool calling
EMBED_MODEL = "nomic-embed-text"  # ollama pull nomic-embed-text
DATA_DIR = "data"                 # drop annual reports / fact sheets (PDF or .txt) here
CHROMA_DIR = "chroma_db"
COLLECTION = "financial_docs"
CHUNK_SIZE = 1200      # large enough to keep a table row + header together
CHUNK_OVERLAP = 250    # overlap so a label and its number survive a boundary
TOP_K = 3
