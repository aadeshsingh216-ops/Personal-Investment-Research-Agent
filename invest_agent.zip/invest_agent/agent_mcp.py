"""BONUS: agent that fetches tools from the MCP server at runtime.
Run the server first, then:  python agent_mcp.py"""
import asyncio
from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain_ollama import ChatOllama
from langchain.agents import create_agent
import config
from agent import SYSTEM_PROMPT


async def main():
    client = MultiServerMCPClient(
        {"finance": {"url": "http://localhost:8001/mcp", "transport": "streamable_http"}}
    )
    tools = await client.get_tools()
    agent = create_agent(ChatOllama(model=config.LLM_MODEL, temperature=0), tools,
                         system_prompt=SYSTEM_PROMPT)
    res = await agent.ainvoke({"messages": [{"role": "user",
                               "content": "Price of AAPL and what the docs say about revenue?"}]})
    print(res["messages"][-1].content)

asyncio.run(main())
