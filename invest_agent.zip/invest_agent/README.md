# Personal Investment Research Agent (Track 2: Finance)

**Team Krazy Coder**: Tshewang Kinley Rigzin, Adesh Singh, Jigme Tenzin

An agent that answers questions from financial documents (RAG over annual reports / fact sheets)
and live market data (stock price and news), and always states whether a number came from the
live market or the static document.

> Disclaimer: educational use only. This is not personalized financial advice.

## Pipeline
LLM setup (ChatOllama) -> document loading -> text splitting -> embeddings -> Chroma vector store
-> retriever -> custom tools (`@tool`) -> ReAct agent (`create_agent`) -> Gradio app.
Bonus: tools served through FastMCP and loaded with `MultiServerMCPClient`.

## Files
| File | Purpose |
|---|---|
| `config.py` | Model names, chunk size, k |
| `ingest.py` | Load, split, embed, persist to Chroma, retriever test |
| `tools.py` | `get_stock_price`, `get_stock_news`, `search_financial_documents` |
| `agent.py` | ChatOllama + system prompt + ReAct agent |
| `app.py` | Gradio UI with disclaimer |
| `mcp_server.py`, `agent_mcp.py` | Bonus MCP version |

## Setup
    pip install -r requirements.txt
    ollama pull llama3.1
    ollama pull nomic-embed-text
    # put an annual report / fact sheet PDF into ./data

## Run
    python ingest.py                                   # build Chroma index
    python ingest.py --test "what was revenue in Q2"   # verify retriever
    python agent.py                                    # CLI smoke test
    python app.py                                      # Gradio UI

## Bonus (MCP)
    python mcp_server.py      # terminal 1
    python agent_mcp.py       # terminal 2

## Example questions
- What was the company's revenue in the latest year in the annual report?
- What is the current price of RELIANCE.NS?
- Compare the reported net profit with today's share price of RELIANCE.NS
